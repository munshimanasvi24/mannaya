import React from "react";

const GiftsPage = () => {
  return (
    <div>
      <h1>Gifts Page</h1>
      <p>This is the Gifts Page.</p>
    </div>
  );
};

export default GiftsPage;
